import java.util.Arrays;
import java.util.Comparator;

public class StringSortByUppercase {
    public static void main(String[] args) {
        String[] strings = {"Hello World", "java programming", "BOMB A BOOM", "SoRtInG ExAmPlE"};

        // Сортування масиву за кількістю великих літер у кожному рядку
        Arrays.sort(strings, new UppercaseLetterCountComparator());

        // Виведення відсортованого масиву
        for (String str : strings) {
            System.out.println(str);
        }
    }
}

class UppercaseLetterCountComparator implements Comparator<String> {
    @Override
    public int compare(String str1, String str2) {
        // Порівнюємо кількість великих літер у двох рядках
        int count1 = countUppercaseLetters(str1);
        int count2 = countUppercaseLetters(str2);

        // Порівнюємо за кількістю великих літер
        return Integer.compare(count1, count2);
    }

    // Метод для підрахунку кількості великих літер у рядку
    private int countUppercaseLetters(String str) {
        int count = 0;
        for (char c : str.toCharArray()) {
            if (Character.isUpperCase(c)) {
                count++;
            }
        }
        return count;
    }
}
