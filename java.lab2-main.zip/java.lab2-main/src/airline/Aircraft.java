package airline;

public class Aircraft {
    public String aircraftNumber;
    public int capacity = 40;

    public Aircraft(String aircraftNumber) {
        this.aircraftNumber = aircraftNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return "Aircraft{" +
                "aircraftNumber='" + aircraftNumber + '\'' +
                ", capacity=" + capacity +
                '}';
    }

    public void minusCapacity() {
        this.capacity--;
    }
}
