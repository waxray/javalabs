package airline;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Calendar;

public class Ticket {
    public final int ticketNumber;
    public final Passenger passenger;
    public final Flight flight;
    public final Date purchaseDate;
    public final double price;
    public final boolean isCancelled;

    public Ticket(int ticketNumber, Passenger passenger, Flight flight, Date purchaseDate, double price) {
        this.ticketNumber = ticketNumber;
        this.passenger = passenger;
        this.flight = flight;
        this.purchaseDate = purchaseDate;
        this.price = price;
        this.isCancelled = false;
    }

    @Override
    public String toString() {
        return "\nTicket {" +
                "ticketNumber=" + ticketNumber +
                ", passenger=" + passenger +
                ", flight=" + flight +
                ", purchaseDate=" + purchaseDate +
                ", price=" + price +
                ", isCancelled=" + isCancelled +
                '}';
    }

    public static List<Ticket> createTickets(Passenger passenger, Flight flight, int numberOfTickets) {
        List<Ticket> tickets = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();

        for (int i = 1; i <= numberOfTickets; i++) {
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            Date currentDate = calendar.getTime();
            double price = 200.0 - i * 20.0;

            Ticket newTicket = new Ticket(i, passenger, flight, currentDate, price);
            tickets.add(newTicket);
        }

        return tickets;
    }
}
