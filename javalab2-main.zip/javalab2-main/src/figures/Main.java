package figures;

public class Main {
    public static void main(String[] args) {
        Shape triangle = new Triangle(5, 4);
        System.out.println("Area of the triangle:" + triangle.calculateArea());
        System.out.println("Volume of the triangle: " + triangle.calculateVolume());

        Shape square = new Square(6);
        System.out.println("Square area: " + square.calculateArea());
        System.out.println("Volume of the square: " + square.calculateVolume());

        Shape rectangle = new Rectangle(6, 8);
        System.out.println("Area of the rectangle: " + rectangle.calculateArea());
        System.out.println("Volume of the rectangle: " + rectangle.calculateVolume());

        Shape cube = new Cube(4);
        System.out.println("Cube area: " + cube.calculateArea());
        System.out.println("Volume of the cube: " + cube.calculateVolume());

        Shape pyramid = new Pyramid(6, 8, 10);
        System.out.println("Area of the pyramid: " + pyramid.calculateArea());
        System.out.println("Volume of the pyramid: " + pyramid.calculateVolume());

        Shape circle = new Circle(3);
        System.out.println("Circle area: " + circle.calculateArea());
        System.out.println("Circle volume: " + circle.calculateVolume());

        Shape sphere = new Sphere(5);
        System.out.println("Area of sphere: " + sphere.calculateArea());
        System.out.println("Volume of sphere: " + sphere.calculateVolume());

    }
}
