package airline;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Calendar;

public class FlightSchedule {
    public List<Flight> flights;

    public FlightSchedule() {
        this.flights = new ArrayList<>();
    }

    public void addFlight(Flight flight) {
        flights.add(flight);
    }

    public void displayFlightSchedule() {
        for (Flight flight : flights) {
            System.out.println("\nFlight Number: " + flight.getFlightNumber());
            System.out.println("Departure Time: " + flight.getDepartureTime());
            System.out.println("Origin Airport: " + flight.getOriginAirport());
            System.out.println("Destination Airport: " + flight.getDestinationAirport());
            System.out.println("Available Seats: " + flight.getAircraft().getCapacity());
        }
    }

    public void generateFlights(int numberOfFlights, Aircraft aircraft) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, Calendar.OCTOBER, 14);

        for (int i = 1; i <= numberOfFlights; i++) {
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            Date departureDate = calendar.getTime();

                Flight newFlight = new Flight("F" + i, departureDate, "Lviv", "Kyiv", aircraft);
            addFlight(newFlight);
        }
        aircraft.minusCapacity();
    }
}