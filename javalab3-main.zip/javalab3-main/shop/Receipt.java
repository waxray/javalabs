package shop;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Receipt {
    private final List<Product> purchasedProducts;
    private final LocalDate purchaseDate;
    private boolean isPaid;
    private Customer customer;
    private PurchaseHistory purchaseHistory;

    public Receipt() {
        this.purchasedProducts = new ArrayList<>();
        this.purchaseDate = LocalDate.now();
        this.isPaid = false;
        this.purchaseHistory = new PurchaseHistory();
    }

    public Receipt(List<Product> purchasedProducts) {
        this();
        this.purchasedProducts.addAll(purchasedProducts);
    }

    public PurchaseHistory getPurchaseHistory() {
        return purchaseHistory;
    }

    public void addProductToReceipt(Product product) {
        if (!isPaid) {
            if (shouldAddAdditionalProducts(product)) {
                FileService fileService = new FileService();
                List<Product> additionalProducts = fileService.loadDataFromFile("products.txt");
                purchasedProducts.addAll(additionalProducts);
            }
            purchasedProducts.add(product);
        } else {
            System.out.println("Cannot add products to a paid receipt.");
        }
    }

    private boolean shouldAddAdditionalProducts(Product product) {
        String category = product.getCategory().toLowerCase();
        return category.equals("fruits") || category.equals("vegetables");
    }

    public List<Product> getPurchasedProducts() {
        return new ArrayList<>(purchasedProducts);
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void markAsPaid() {
        this.isPaid = true;
    }

    public boolean isPaid() {
        return isPaid;
    }

    public void updatePurchasedProducts(List<Product> newProducts) {
        if (!isPaid) {
            purchasedProducts.clear();
            purchasedProducts.addAll(newProducts);
        } else {
            System.out.println("Cannot edit a paid receipt.");
        }
    }

    public void addCustomer(Customer customer) {
        this.customer = customer;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        if (!isPaid) {
            this.customer = customer;
        } else {
            System.out.println("Cannot change the customer of a paid receipt.");
        }
    }

}
