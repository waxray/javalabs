package airline;

public class Passenger {
    public final String name;
    public final String passportNumber;

    public Passenger(String name, String passportNumber) {
        this.name = name;
        this.passportNumber = passportNumber;
    }
}
