package airline;

import java.util.Date;

public class Ticket {
    public final int ticketNumber;
    public final Passenger passenger;
    public final Flight flight;
    public final Date purchaseDate;
    public final double price;
    public final boolean isCancelled;

    public Ticket(int ticketNumber, Passenger passenger, Flight flight, Date purchaseDate, double price) {
        this.ticketNumber = ticketNumber;
        this.passenger = passenger;
        this.flight = flight;
        this.purchaseDate = purchaseDate;
        this.price = price;
        this.isCancelled = false;
    }
}
