package airline;

public class Airport {
    public final String code;
    public final String name;

    public Airport(String code, String name) {
        this.code = code;
        this.name = name;
    }
}
