package com.shipment;

class Shipment {
    private static int shipmentCounter = 0;
    private boolean isCanceled;
    private int shipmentId;
    private Customer sender;
    private Customer receiver;
    private Item[] items;
    private String deliveryMethod;

    public Shipment(Customer sender, Customer receiver, Item[] items, String deliveryMethod) {
        this.shipmentId = ++shipmentCounter;
        this.sender = sender;
        this.receiver = receiver;
        this.items = items;
        this.deliveryMethod = deliveryMethod;
        this.isCanceled = false;
    }

    public static Shipment createShipment(Customer sender, Customer receiver, Item[] items, String deliveryMethod) {
        return new Shipment(sender, receiver, items, deliveryMethod);
    }

    // Method to cancel the shipment
    public void cancelShipment() {
        if (!isCanceled) {
            isCanceled = true;
            System.out.println("Shipment ID " + shipmentId + " has been canceled.");
        } else {
            System.out.println("Shipment ID " + shipmentId + " is already canceled.");
        }
    }

    public boolean isCanceled() {
        return isCanceled;
    }

    // Method to calculate the total weight of items in the shipment
    public double calculateTotalWeight() {
        double totalWeight = 0;
        for (Item item : items) {
            totalWeight += item.getWeight();
        }
        return totalWeight;
    }

    // Method to calculate the total size of items in the shipment
    public double calculateTotalSize() {
        double totalSize = 0;
        for (Item item : items) {
            totalSize += item.getSize();
        }
        return totalSize;
    }

    public int getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(int shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Customer getSender() {
        return sender;
    }

    public void setSender(Customer sender) {
        this.sender = sender;
    }

    public Customer getReceiver() {
        return receiver;
    }

    public void setReceiver(Customer receiver) {
        this.receiver = receiver;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

}
