package airline;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Passenger passenger = new Passenger("Max Manianov", "AB12345");
        Aircraft aircraft = new Aircraft("A123");
        Airport airport = new Airport("1st", "Lviv");
        System.out.println("\nAirport Code: " + airport.code);
        System.out.println("Airport Name: " + airport.name + "\n");

        FlightSchedule flightSchedule = new FlightSchedule();
        flightSchedule.generateFlights(5, aircraft);

        System.out.print("Flight Schedule:");
        flightSchedule.displayFlightSchedule();

        List<Ticket> tickets = new ArrayList<>();
        List<Ticket> newTickets = Ticket.createTickets(passenger, flightSchedule.flights.get(0), 5);
        tickets.addAll(newTickets);

        for (Ticket newTicket : newTickets) {
            System.out.println(newTicket);
        }

        AirlineProfitCalculator calculator = new AirlineProfitCalculator();
        double profitLastWeek = calculator.calculateProfitLastWeek(tickets);
        System.out.println("\nProfit for the last week: " + profitLastWeek);

        double averageTicketPrice = calculator.calculateAverageTicketPrice(tickets);
        System.out.println("Average ticket price: " + averageTicketPrice);

    }
}