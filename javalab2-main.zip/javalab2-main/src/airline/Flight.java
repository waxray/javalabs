package airline;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Flight {
    public final String flightNumber;
    public final Date departureTime;
    public final String originAirport;
    public final String destinationAirport;
    public final Aircraft aircraft;
    public final List<Ticket> tickets;

    public Flight(String flightNumber, Date departureTime, String originAirport, String destinationAirport, Aircraft aircraft) {
        this.flightNumber = flightNumber;
        this.departureTime = departureTime;
        this.originAirport = originAirport;
        this.destinationAirport = destinationAirport;
        this.aircraft = aircraft;
        this.tickets = new ArrayList<>();
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public Date getDepartureTime() {
        return departureTime;
    }

    public String getOriginAirport() {
        return originAirport;
    }

    public String getDestinationAirport() {
        return destinationAirport;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }
}
