package airline;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Flight {
    private String flightNumber;
    private Date departureTime;
    private String originAirport;
    private String destinationAirport;

    @Override
    public String toString() {
        return "Flight{" +
                "flightNumber='" + flightNumber + '\'' +
                ", departureTime=" + departureTime +
                ", originAirport='" + originAirport + '\'' +
                ", destinationAirport='" + destinationAirport + '\'' +
                ", aircraft=" + aircraft +
                ", tickets=" + tickets +
                '}';
    }

    private Aircraft aircraft;
    private List<Ticket> tickets;

    public Flight(String flightNumber, Date departureTime, String originAirport, String destinationAirport, Aircraft aircraft) {
        this.flightNumber = flightNumber;
        this.departureTime = departureTime;
        this.originAirport = originAirport;
        this.destinationAirport = destinationAirport;
        this.aircraft = aircraft;
        this.tickets = new ArrayList<>();
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public Date getDepartureTime() {
        return departureTime;
    }

    public String getOriginAirport() {
        return originAirport;
    }

    public String getDestinationAirport() {
        return destinationAirport;
    }

    public Aircraft getAircraft() {
        return aircraft;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

}
