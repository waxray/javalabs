package figures;

public class Pyramid extends Shape {
    private final double baseLength;
    private final double baseWidth;
    private final double height;

    public Pyramid(double baseLength, double baseWidth, double height) {
        this.baseLength = baseLength;
        this.baseWidth = baseWidth;
        this.height = height;
    }

    @Override
    public double calculateArea() {
        double baseArea = baseLength * baseWidth;
        double sideArea = baseLength * Math.sqrt((baseWidth / 2) * (baseWidth / 2) + height * height);
        return baseArea + 4 * sideArea;
    }

    @Override
    public double calculateVolume() {
        return (1.0 / 3) * baseLength * baseWidth * height;
    }
}
