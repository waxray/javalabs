package airline;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Aircraft aircraft = new Aircraft("A123", 150);
        Flight flight = new Flight("F123", new Date(), "Airport1", "Airport2", aircraft);
        Passenger passenger = new Passenger("John Doe", "AB12345");

        Airport airport = new Airport("AP1", "Airport 1");
        System.out.println("\nAirport Code: " + airport.code);
        System.out.println("Airport Name: " + airport.name);

        Ticket ticket = new Ticket(1, passenger, flight, new Date(), 100.0);
        System.out.println("Ticket Number: " + ticket.ticketNumber);
        System.out.println("Passenger Name: " + ticket.passenger.name);
        System.out.println("Flight Number: " + ticket.flight.flightNumber);
        System.out.println("Purchase Date: " + ticket.purchaseDate);
        System.out.println("Ticket Price: " + ticket.price);
        System.out.println("Is Cancelled: " + ticket.isCancelled);

        FlightSchedule flightSchedule = new FlightSchedule();
        flightSchedule.addFlight(flight);

        System.out.println("Flight Schedule:");
        flightSchedule.displayFlightSchedule();
    }
}