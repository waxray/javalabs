package airline;

import java.util.Date;
import java.util.List;

public class AirlineProfitCalculator {

    public double calculateAverageTicketPrice(List<Ticket> tickets) {
        if (tickets.isEmpty()) {
            return 0.0;
        }

        double totalPrice = 0.0;
        for (Ticket ticket : tickets) {
            totalPrice += ticket.price;
        }

        return totalPrice / tickets.size();
    }


    public double calculateProfitLastWeek(List<Ticket> tickets) {
        Date currentDate = new Date();
        long oneWeek = 7 * 24 * 60 * 60 * 1000;

        Date lastWeekStartDate = new Date(currentDate.getTime() - oneWeek);

        double totalProfit = 0.0;

        for (Ticket ticket : tickets) {
            if (ticket.purchaseDate.after(lastWeekStartDate) && ticket.purchaseDate.before(currentDate)) {
                totalProfit += ticket.price;
            }
        }

        return totalProfit;
    }
}
