package shop;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FileService {

    public void generateOrderReceipt(String fileName, Receipt receipt) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("Order Receipt\n");
            writer.write("Date: " + receipt.getPurchaseDate() + "\n");
            writer.write("Items:\n");

            List<Product> meatAndFishProducts = new ArrayList<>();
            List<Product> fruitsAndVegetables = new ArrayList<>();

            for (Product product : receipt.getPurchasedProducts()) {
                writeProductDetails(writer, product);

                categorizeProduct(product, meatAndFishProducts, fruitsAndVegetables);
            }

            writeRefrigeratorReminder(writer, meatAndFishProducts);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeProductDetails(BufferedWriter writer, Product product) throws IOException {
        writer.write(product.getName() + " | Price: " + product.getPrice() + "\n");
    }

    private void categorizeProduct(Product product, List<Product> meatAndFishProducts, List<Product> fruitsAndVegetables) {
        if (isCategory(product, "meat", "fish")) {
            meatAndFishProducts.add(product);
        } else if (isCategory(product, "fruits", "vegetables")) {
            fruitsAndVegetables.add(product);
        }
    }

    private boolean isCategory(Product product, String... categories) {
        for (String category : categories) {
            if (product.getCategory().equalsIgnoreCase(category)) {
                return true;
            }
        }
        return false;
    }

    private void writeRefrigeratorReminder(BufferedWriter writer, List<Product> meatAndFishProducts) throws IOException {
        if (!meatAndFishProducts.isEmpty()) {
            writer.write("Don't forget to store items ");
            for (int i = 0; i < meatAndFishProducts.size(); i++) {
                writer.write(meatAndFishProducts.get(i).getName());
                if (i < meatAndFishProducts.size() - 1) {
                    writer.write(", ");
                } else {
                    writer.write(" in the refrigerator\n");
                }
            }
        }
    }

    public List<Product> loadDataFromFile(String fileName) {
        List<Product> products = new ArrayList<>();

        try {
            products = Files.lines(Path.of(fileName))
                    .map(this::mapToProduct)
                    .filter(product -> product != null)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return products;
    }

    private Product mapToProduct(String line) {
        String[] parts = line.split(",");
        if (parts.length == 3) {
            String name = parts[0].trim();
            String category = parts[1].trim();
            double price = Double.parseDouble(parts[2].trim());
            return new Product(name, price, category);
        }
        return null;
    }
}
