import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number of rows for the first matrix: ");
        int rowsA = input.nextInt();
        System.out.println("Enter the number of columns for the first matrix: ");
        int colsA = input.nextInt();

        System.out.println("Enter the number of rows for the second matrix: ");
        int colsB = input.nextInt();
        System.out.println("Enter the number of columns for the second matrix: ");
        int rowsB = input.nextInt();

        int[][] matrixA = new int[rowsA][colsA];
        int[][] matrixB = new int[rowsB][colsB];

        System.out.println("Enter the elements of the first matrix: ");
        inputMatrix(matrixA, input);

        System.out.println("Enter the elements of the second matrix: ");
        inputMatrix(matrixB, input);

        input.close();

        // Виклик функції для множення матриць
        int[][] resultMatrix = multiplyMatrices(matrixA, matrixB);

        // Виведення результату
        System.out.println("Result of matrix multiplication: ");
        printMatrix(resultMatrix);
    }

    public static void inputMatrix(int[][] matrix, Scanner input) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                matrix[i][j] = input.nextInt();
            }
        }
    }

    public static int[][] multiplyMatrices(int[][] A, int[][] B) {
        int rowsA = A.length;
        int colsA = A[0].length;
        int colsB = B[0].length;

        // Перевірка на можливість множення матриць
        if (colsA != B.length) {
            throw new IllegalArgumentException("It's not possible to multiply matrices. The dimensions do not match.");
        }

        // Створення результату (пустої матриці)
        int[][] result = new int[rowsA][colsB];

        // Виконання множення матриць
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                int sum = 0;
                for (int k = 0; k < colsA; k++) {
                    sum += A[i][k] * B[k][j];
                }
                result[i][j] = sum;
            }
        }

        return result;
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
    }
}
