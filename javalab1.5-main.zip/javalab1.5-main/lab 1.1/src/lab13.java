public class lab13 {
    public static void main(String[] args) {
        String email1 = "example@email.com";
        String email2 = "invalid-email";

        System.out.println(validateEmail(email1)); // Виведе true
        System.out.println(validateEmail(email2)); // Виведе false
    }

    public static boolean validateEmail(final String email) {
        // Перевірка наявності символа '@'
        int atIndex = email.indexOf('@');
        if (atIndex == -1) {
            return false;
        }

        // Перевірка наявності символу '.' після символа '@'
        int dotIndex = email.indexOf('.', atIndex);
        if (dotIndex == -1) {
            return false;
        }

        // Перевірка, що символ '@' не є першим символом і не є останнім символом
        if (atIndex == 0 || atIndex == email.length() - 1) {
            return false;
        }

        // Перевірка, що символ '.' не є першим символом після символа '@'
        if (dotIndex == atIndex + 1) {
            return false;
        }

        // Перевірка, що символ '.' не є останнім символом
        if (dotIndex == email.length() - 1) {
            return false;
        }

        return true;
    }
}
