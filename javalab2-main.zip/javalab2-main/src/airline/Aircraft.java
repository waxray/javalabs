package airline;

public class Aircraft {
    public final String aircraftNumber;
    public final int capacity;

    public Aircraft(String aircraftNumber, int capacity) {
        this.aircraftNumber = aircraftNumber;
        this.capacity = capacity;
    }

    public int getCapacity() {
        return capacity;
    }
}
