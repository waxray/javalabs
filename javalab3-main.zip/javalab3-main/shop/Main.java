package shop;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        performShopOperations();
    }

    private static void performShopOperations() {
        FileService fileService = new FileService();
        List<Product> products = fileService.loadDataFromFile("products.txt");
        Store store = new Store(products);
        Customer customer1 = new Customer("Max", "Manya");

        displayAvailableProducts(products);

        Receipt receipt1 = createAndProcessReceipt(store, customer1, products);

        editProductPriceAndDisplay(store, products);

        List<Product> orderedProducts = store.orderProduct("fruits", 5.0);
        fileService.generateOrderReceipt("order_receipt.txt", receipt1);

        displayReceiptComment(receipt1);

        ShopService shopService = new ShopService();
        performShopAnalytics(shopService, products, customer1, receipt1);

        handleReceiptEditing(store, products);
    }

    private static void displayAvailableProducts(List<Product> products) {
        System.out.println("All available products:");
        products.forEach(product -> System.out.println(product.getName()));
    }

    private static Receipt createAndProcessReceipt(Store store, Customer customer, List<Product> products) {
        Receipt receipt = createSampleReceipt(store, customer, products);
        PurchaseHistory purchaseHistory = new PurchaseHistory();
        purchaseHistory.addPurchaseToHistory(customer, receipt);
        return receipt;
    }

    private static void editProductPriceAndDisplay(Store store, List<Product> products) {
        System.out.println("Before editing price:");
        System.out.println(products.get(0).getPrice());
        store.editProductPrice(products.get(0).getName(), 15.0);
        System.out.println("After editing price:");
        System.out.println(products.get(0).getPrice());
    }

    private static void displayReceiptComment(Receipt receipt) {
        System.out.println("Receipt comment:");
        System.out.println(receipt.getPurchaseHistory().generateReceiptComment(receipt));
    }

    private static void performShopAnalytics(ShopService shopService, List<Product> products, Customer customer, Receipt receipt) {
        List<Product> sortedProducts = shopService.filterAndSortProductsByPrice(products);
        double averagePrice = shopService.calculateAveragePrice(products);
        double userExpenses = shopService.calculateUserExpenses(customer, List.of(receipt));
        Map<Product, Long> productsCount = shopService.getProductsCountForCustomer(customer, List.of(receipt));
        Product mostPopularProduct = shopService.findMostPopularProduct(List.of(receipt));
        double maxDailyIncome = shopService.findMaxDailyIncome(List.of(receipt));

        System.out.println("Sorted products by price:");
        sortedProducts.forEach(product -> System.out.println(product.getName()));

        System.out.println("Average price of all products: " + averagePrice);

        System.out.println("Expenses of " + customer.getFirstName() + ": " + userExpenses);

        System.out.println("Products count for " + customer.getFirstName() + ": " + productsCount);

        System.out.println("Most popular product: " + mostPopularProduct.getName());

        System.out.println("Max daily income: " + maxDailyIncome);
    }

    private static void handleReceiptEditing(Store store, List<Product> products) {
        Product product1 = new Product("Apple", 2.5, "Fruit");
        Product product2 = new Product("Chicken", 8.0, "Meat");
        Product product3 = new Product("Carrot", 1.0, "Vegetable");

        List<Product> unpaidProducts = new ArrayList<>();
        unpaidProducts.add(product1);
        unpaidProducts.add(product2);

        List<Product> paidProducts = new ArrayList<>();
        paidProducts.add(product2);
        paidProducts.add(product3);

        Receipt unpaidReceipt = new Receipt(unpaidProducts);
        Receipt paidReceipt = new Receipt(paidProducts);
        paidReceipt.markAsPaid();

        System.out.println("Editing unpaid receipt:");
        unpaidReceipt.updatePurchasedProducts(paidProducts);

        System.out.println("\nEditing paid receipt:");
        paidReceipt.updatePurchasedProducts(unpaidProducts);
    }

    private static Receipt createSampleReceipt(Store store, Customer customer, List<Product> products) {
        Receipt receipt = new Receipt();
        receipt.addProductToReceipt(products.get(3));
        receipt.addProductToReceipt(products.get(1));
        receipt.addProductToReceipt(products.get(2));
        receipt.addProductToReceipt(products.get(4));
        receipt.addCustomer(customer);
        receipt.markAsPaid();
        return receipt;
    }
}
