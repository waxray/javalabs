package com.shipment;

public class Main {
    public static void main(String[] args) {
        // Create customers
        Customer sender = new Customer("John Doe", "123 Main St");
        Customer receiver = new Customer("Alice Smith", "456 Elm St");

        // Create items
        Item item1 = new Item("Book", 0.5, 10.0);
        Item item2 = new Item("Laptop", 2.0, 20.0);

        // Create shipments
        Shipment shipment1 = Shipment.createShipment(sender, receiver, new Item[]{item1}, "Truck");
        Shipment shipment2 = Shipment.createShipment(sender, receiver, new Item[]{item2}, "Bicycle");

        // Calculate and print shipment details
        System.out.println("Shipment 1 details:");
        System.out.println("Shipment ID: " + shipment1.getShipmentId());
        System.out.println("Sender: " + sender.getName() + ", Address: " + sender.getAddress());
        System.out.println("Receiver: " + receiver.getName() + ", Address: " + receiver.getAddress());
        System.out.println("Total Weight: " + shipment1.calculateTotalWeight() + " kg");
        System.out.println("Total Size: " + shipment1.calculateTotalSize() + " cubic cm");

        System.out.println("\nShipment 2 details:");
        System.out.println("Shipment ID: " + shipment2.getShipmentId());
        System.out.println("Sender: " + sender.getName() + ", Address: " + sender.getAddress());
        System.out.println("Receiver: " + receiver.getName() + ", Address: " + receiver.getAddress());
        System.out.println("Total Weight: " + shipment2.calculateTotalWeight() + " kg");
        System.out.println("Total Size: " + shipment2.calculateTotalSize() + " cubic cm");

        // Cancel shipment 1
        shipment1.cancelShipment();
        if (shipment1.isCanceled()) {
            System.out.println("\nShipment 1 has been canceled.");
        }
    }
}




