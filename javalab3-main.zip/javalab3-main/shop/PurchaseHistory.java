package shop;

import java.util.HashMap;
import java.util.Map;

public class PurchaseHistory {
    private final Map<Customer, Receipt> purchaseHistory;

    public PurchaseHistory() {
        this.purchaseHistory = new HashMap<>();
    }

    public void addPurchaseToHistory(Customer customer, Receipt receipt) {
        purchaseHistory.put(customer, receipt);
    }

    public String generateReceiptComment(Receipt receipt) {
        StringBuilder comment = new StringBuilder("Your purchase receipt on " + receipt.getPurchaseDate() + ":\n");
        appendProductDetails(comment, receipt.getPurchasedProducts());
        return comment.toString();
    }

    private void appendProductDetails(StringBuilder comment, Iterable<Product> products) {
        for (Product product : products) {
            comment.append("- ").append(product.getName()).append("\n");
        }
    }
}
